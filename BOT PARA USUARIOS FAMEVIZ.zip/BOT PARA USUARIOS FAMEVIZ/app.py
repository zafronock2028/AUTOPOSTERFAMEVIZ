from flask import Flask, render_template, request, redirect, session
from telethon.sync import TelegramClient
import asyncio
import os

app = Flask(__name__)
app.secret_key = 'clave_secreta'

@app.route('/', methods=['GET'])
def index():
    return render_template('login.html')

@app.route('/verify', methods=['POST'])
def verify():
    session['phone'] = request.form['phone']
    session['api_id'] = int(request.form['api_id'])
    session['api_hash'] = request.form['api_hash']
    session['ref_link'] = request.form['ref_link']

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    client = TelegramClient('bot_session', session['api_id'], session['api_hash'], loop=loop)
    client.connect()
    if not client.is_user_authorized():
        client.send_code_request(session['phone'])

    client.disconnect()
    return redirect('/code')

@app.route('/code', methods=['GET', 'POST'])
def code():
    if request.method == 'POST':
        code = request.form['code']

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        client = TelegramClient('bot_session', session['api_id'], session['api_hash'], loop=loop)
        client.connect()
        if not client.is_user_authorized():
            client.sign_in(session['phone'], code)

        session['logged_in'] = True
        client.disconnect()
        return redirect('/panel')

    return render_template('code.html')

@app.route('/panel')
def panel():
    if not session.get('logged_in'):
        return redirect('/')
    return render_template('panel.html', ref_link=session.get('ref_link', ''))

if __name__ == '__main__':
    app.run(debug=True)
