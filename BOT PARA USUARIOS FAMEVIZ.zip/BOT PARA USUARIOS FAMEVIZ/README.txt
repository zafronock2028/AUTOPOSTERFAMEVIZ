GUÍA DE USO – Fameviz Bot Lite

1. Extrae el contenido del ZIP.
2. Abre una terminal (CMD) en la carpeta extraída.
3. Ejecuta: python app.py
4. Accede al panel desde tu navegador: http://localhost:8501
5. Ingresa tu número de Telegram, API ID, API Hash y tu link de Fameviz.
6. Coloca el código que te llega por Telegram.
7. ¡Listo! Ya puedes seleccionar imágenes y textos y publicar en tus grupos.

Cualquier intento de publicar otro negocio será bloqueado.
Contacto para versión Pro: @ZafronockBitFratsG
